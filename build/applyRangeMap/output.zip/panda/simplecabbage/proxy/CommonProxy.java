package panda.simplecabbage.proxy;

import net.minecraftforge.client.event.ModelRegistryEvent;

public class CommonProxy {

    public static void registerModels(ModelRegistryEvent event) {
    	//Need to have this empty
    }
}

