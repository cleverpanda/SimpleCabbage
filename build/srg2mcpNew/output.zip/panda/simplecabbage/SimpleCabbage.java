package panda.simplecabbage;

import java.util.Set;

import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.gen.structure.MapGenStructureIO;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLConstructionEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.VillagerRegistry;
import panda.simplecabbage.gen.ComponentCabbageField;
import panda.simplecabbage.gen.CabbageWorldGen;
import panda.simplecabbage.init.ModItems;
import panda.simplecabbage.other.DropSeedsHandler;
import panda.simplecabbage.other.ImmersiveEngineeringCompat;
import panda.simplecabbage.other.ThermalCompat;
import panda.simplecabbage.proxy.CommonProxy;

@Mod(modid = SimpleCabbage.MODID, name = SimpleCabbage.NAME, version = SimpleCabbage.VERSION, dependencies = "after:immersiveengineering;after:thermalexpansion")

public class SimpleCabbage {	
	
	public static final String MODID = "simplecabbage";
	public static final String NAME = "Simple Cabbage";
	public static final String VERSION = "1.0.7";
	
	private static boolean isIEInstalled;
	private static boolean isThermalInstalled;
	public Configuration config;
	
	@Instance(MODID)
	public static SimpleCabbage instance;
	
	@SidedProxy(clientSide = "panda.simplecabbage.proxy.ClientProxy", serverSide = "panda.simplecabbage.proxy.ServerProxy")
	public static CommonProxy proxy;
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent event){
		config = new Configuration(event.getSuggestedConfigurationFile());
		ConfigSimpleCabbage.load(config);
		
		if(ConfigSimpleCabbage.generatefarms) {
			MapGenStructureIO.registerStructureComponent(ComponentCabbageField.class, "Vicaf");
			VillagerRegistry.instance().registerVillageCreationHandler(new CabbageWorldGen());
		}
		
		MinecraftForge.EVENT_BUS.register(new DropSeedsHandler());
		
	}
	
	@SuppressWarnings("unchecked")
	@EventHandler
	public void init(FMLInitializationEvent event){
		if(isIEInstalled){
			ImmersiveEngineeringCompat.init();
		}
		
		if(isThermalInstalled){
			ThermalCompat.init();
		}
		
		((Set<Item>) ObfuscationReflectionHelper.getPrivateValue(    EntityPig.class, null, "TEMPTATION_ITEMS")).add(ModItems.CABBAGE_HEAD);
		((Set<Item>) ObfuscationReflectionHelper.getPrivateValue(EntityChicken.class, null, "TEMPTATION_ITEMS")).add(ModItems.CABBAGE_SEEDS);
		
		MinecraftForge.addGrassSeed(new ItemStack(ModItems.CABBAGE_SEEDS), ConfigSimpleCabbage.seedsWeight);

		VillagerRegistry.FARMER.getCareer(0).addTrade(1, new EntityVillager.EmeraldForItems(ModItems.CABBAGE_HEAD, new EntityVillager.PriceInfo(15, 19)));
	}
	
	@EventHandler
	public static void onConstructionEvent(FMLConstructionEvent event) {
		isIEInstalled = Loader.isModLoaded("immersiveengineering");
		isThermalInstalled = Loader.isModLoaded("thermalexpansion");
	}

}
